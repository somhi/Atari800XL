rm a8core/atari800nx_core_simple_sdram.vhd
rm a8core/atari800core_helloworld.vhd
rm a8core/atari800core_simple_sdram.vhd
rm a8core/atari5200core.vhd
rm a8core/atari800xl.vhd
rm a8core/atari5200core_simplesdram.vhd
rm a8core/internalromram_*
rm -rf a8core/address_decoder_rework
